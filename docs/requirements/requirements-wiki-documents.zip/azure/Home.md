# Requirements

- [Home](Home)
- [Project Overview](Project-Overview)
- Architecture and Design
  - [Architecture](Architecture)
  - [Emulator Adapter Contract](Emulator-Adapter-Contract)
  - [C4 Model](C4-Model)
  - [Wireframes and Storyboards](Wireframes-and-Storyboards)
  - [Shared SVG Components](Shared-SVG-Components)
  - [Git Integration](Git-Integration)
  - [Language Server Support](Language-Server-Support)
  - [MCP Tools](MCP-Tools)
- [Functional Requirements](Functional-Requirements)
- [Technical Requirements](Technical-Requirements)
- [Testing Requirements](Testing-Requirements)
- [TR per FR Mapping](TR-per-FR-Mapping)
- [Requirements Matrix](Requirements-Matrix)
- [Requirement Ownership](Requirement-Ownership)
